import http from 'node:http';
import { performance } from 'node:perf_hooks';
import { WebSocketServer, WebSocket } from 'ws';

const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 8787);

const BASE_URL =
  'http://www.kmoni.bosai.go.jp/data/map_img/RealTimeImg/jma_s/';

const LATEST_URL =
  'http://www.kmoni.bosai.go.jp/webservice/server/pros/latest.json';

const POINTS_URL =
  'https://raw.githubusercontent.com/ingen084/kyoshin-monitor-observation-points/refs/heads/master/intensity-points.json';

const POLL_MS = 500;
const FALLBACK_SECONDS = 3;

const FETCH_TIMEOUT = 2500;
const LATEST_TIMEOUT = 2000;

const ALLOWED_ORIGINS = [];

function formatJST(ms) {
  if (!ms) return null;

  return new Date(ms + 9 * 3600e3)
    .toISOString()
    .replace('T', ' ')
    .slice(0, 19) + ' JST';
}

const clients = new Set();

const server = http.createServer(async (req, res) => {
  const url = new URL(
    req.url || '/',
    `http://${req.headers.host || 'localhost'}`
  );

  if (req.method === 'GET' && url.pathname === '/status') {
    const now = Date.now();

    const latestAgeMs = collector.latestMs
      ? now - collector.latestMs
      : null;

    const imageAgeMs = collector.lastMs
      ? now - collector.lastMs
      : null;

    const latestToImageMs =
      collector.latestMs && collector.lastMs
        ? collector.latestMs - collector.lastMs
        : null;

    const imageToBroadcastMs =
      collector.lastBroadcastMs && collector.lastMs
        ? collector.lastBroadcastMs - collector.lastMs
        : null;

    const body = {
      version: 'node collector v2',

      clients: clients.size,
      stations: collector.stations.length,

      currentTime: now,
      currentTimeJST: formatJST(now),

      latestMs: collector.latestMs || null,
      latestJST: formatJST(collector.latestMs),

      lastImageMs: collector.lastMs || null,
      lastImageJST: formatJST(collector.lastMs),

      lastBroadcastMs: collector.lastBroadcastMs || null,
      lastBroadcastJST: formatJST(collector.lastBroadcastMs),

      latestAgeMs,
      latestAgeSeconds:
        latestAgeMs !== null
          ? Number((latestAgeMs / 1000).toFixed(3))
          : null,

      imageAgeMs,
      imageAgeSeconds:
        imageAgeMs !== null
          ? Number((imageAgeMs / 1000).toFixed(3))
          : null,

      latestToImageMs,
      latestToImageSeconds:
        latestToImageMs !== null
          ? Number((latestToImageMs / 1000).toFixed(3))
          : null,

      imageToBroadcastMs,
      imageToBroadcastSeconds:
        imageToBroadcastMs !== null
          ? Number((imageToBroadcastMs / 1000).toFixed(3))
          : null,

      pollIntervalMs: POLL_MS,

      nextPollInMs:
        collector.timer !== null && collector.nextPollAt
          ? Math.max(
              0,
              Math.round(
                collector.nextPollAt - performance.now()
              )
            )
          : null,

      serverMs: collector.serverMs,

      lastLatestFetchMs: collector.lastLatestFetchMs,
      lastImageFetchMs: collector.lastImageFetchMs,
      lastDecodeMs: collector.lastDecodeMs,
      lastProcessMs: collector.lastProcessMs,
      lastAlarmGapMs: collector.lastAlarmGapMs,

      lastAttemptMs: collector.lastAttemptMs || null,
      lastSuccessMs: collector.lastSuccessMs || null,

      consecutiveErrors: collector.consecutiveErrors,
      lastErr: collector.lastErr,

      alarmScheduled: collector.timer !== null,
      running: collector.running
    };

    res.writeHead(200, {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'access-control-allow-origin': '*'
    });

    res.end(JSON.stringify(body, null, 2));
    return;
  }

  res.writeHead(426, {
    'content-type': 'text/plain; charset=utf-8',
    'cache-control': 'no-store'
  });

  res.end('WebSocket endpoint. GET /status for status.');
});

const wss = new WebSocketServer({
  noServer: true,
  perMessageDeflate: false,
  maxPayload: 1024 * 1024
});

server.on('upgrade', (req, socket, head) => {
  const url = new URL(
    req.url || '/',
    `http://${req.headers.host || 'localhost'}`
  );

  if (url.pathname !== '/') {
    socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
    socket.destroy();
    return;
  }

  if (
    ALLOWED_ORIGINS.length &&
    !ALLOWED_ORIGINS.includes(req.headers.origin || '')
  ) {
    socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
    socket.destroy();
    return;
  }

  wss.handleUpgrade(req, socket, head, ws => {
    wss.emit('connection', ws, req);
  });
});

class Collector {
  constructor() {
    this.points = null;
    this.pointsPromise = null;

    this.stations = [];
    this.prevKeys = new Uint32Array(0);

    this.w = 0;
    this.h = 0;

    this.lastMs = 0;
    this.serverMs = 0;
    this.lastErr = '';

    this.latestMs = 0;
    this.lastBroadcastMs = 0;

    this.lastAttemptMs = 0;
    this.lastSuccessMs = 0;

    this.lastLatestFetchMs = 0;
    this.lastImageFetchMs = 0;
    this.lastDecodeMs = 0;

    this.lastProcessMs = 0;
    this.lastAlarmGapMs = 0;

    this.consecutiveErrors = 0;

    this.running = false;
    this.timer = null;

    // 単調増加時計による周期管理
    this.nextPollAt = 0;
  }

  start() {
    if (
      this.timer !== null ||
      this.running ||
      clients.size === 0
    ) {
      return;
    }

    this.nextPollAt = performance.now();

    this.timer = setTimeout(() => {
      this.timer = null;
      this.poll();
    }, 0);
  }

  stopIfIdle() {
    if (clients.size !== 0) return;

    if (this.timer !== null) {
      clearTimeout(this.timer);
    }

    this.timer = null;
    this.nextPollAt = 0;
  }

  scheduleNext() {
    if (clients.size === 0) {
      this.stopIfIdle();
      return;
    }

    if (this.timer !== null) {
      clearTimeout(this.timer);
    }

    const now = performance.now();

    if (!this.nextPollAt) {
      this.nextPollAt = now;
    }

    // 前回の予定時刻から500ms進める
    this.nextPollAt += POLL_MS;

    // 処理が500msを超えた場合は、
    // 遅れた周期を飛ばして次の未来の予定時刻に合わせる
    while (this.nextPollAt <= now) {
      this.nextPollAt += POLL_MS;
    }

    const delay = Math.max(
      0,
      this.nextPollAt - now
    );

    this.timer = setTimeout(() => {
      this.timer = null;
      this.poll();
    }, delay);
  }

  async poll() {
    if (clients.size === 0 || this.running) {
      this.stopIfIdle();
      return;
    }

    this.running = true;

    const t0 = Date.now();

    if (this.lastAttemptMs) {
      this.lastAlarmGapMs =
        t0 - this.lastAttemptMs;
    }

    this.lastAttemptMs = t0;

    if (!this.nextPollAt) {
      this.nextPollAt = performance.now();
    }

    try {
      await this.step(clients.size);

      this.lastErr = '';
      this.consecutiveErrors = 0;

    } catch (e) {
      const msg = String(
        (e && e.message) || e
      );

      this.lastErr = msg;
      this.consecutiveErrors++;

      this.broadcastText(
        JSON.stringify({
          type: 'error',
          msg,
          consecutiveErrors: this.consecutiveErrors
        })
      );

      console.error(
        new Date().toISOString(),
        'collector:',
        msg
      );

    } finally {
      this.serverMs = Date.now() - t0;

      this.running = false;

      this.scheduleNext();
    }
  }

  async step(clientCount) {
    const t0 = Date.now();

    const latestStart = Date.now();

    const latest = await this.fetchLatest();

    this.lastLatestFetchMs =
      Date.now() - latestStart;

    this.latestMs = latest;

    // 新しい画像が公開されていなければ解析しない
    if (latest <= this.lastMs) {
      this.lastProcessMs = Date.now() - t0;
      return;
    }

    const points = await this.loadPoints();

    let img = null;
    let usedMs = 0;
    let lastError = null;

    const imageStart = Date.now();

    for (
      let i = 0;
      i <= FALLBACK_SECONDS;
      i++
    ) {
      const cand = latest - i * 1000;

      if (cand <= this.lastMs) {
        break;
      }

      try {
        const res = await fetch(
          imageUrlFor(cand),
          {
            signal: AbortSignal.timeout(
              FETCH_TIMEOUT
            ),

            headers: {
              'Cache-Control': 'no-cache',
              'Pragma': 'no-cache'
            }
          }
        );

        if (!res.ok) {
          throw new Error(
            '画像 HTTP ' + res.status
          );
        }

        const buf = new Uint8Array(
          await res.arrayBuffer()
        );

        if (!buf.length) {
          throw new Error('空の画像');
        }

        const decodeStart = Date.now();

        img = decodeGif(buf);

        this.lastDecodeMs =
          Date.now() - decodeStart;

        usedMs = cand;

        break;

      } catch (e) {
        lastError = e;
      }
    }

    this.lastImageFetchMs =
      Date.now() - imageStart;

    if (!img) {
      throw new Error(
        '最新画像を取得できません。' +
        ((lastError && lastError.message) || '')
      );
    }

    let rebuilt = false;

    if (
      img.W !== this.w ||
      img.H !== this.h ||
      !this.stations.length
    ) {
      this.w = img.W;
      this.h = img.H;

      this.stations = points.filter(
        p =>
          p.x >= 0 &&
          p.y >= 0 &&
          p.x < img.W &&
          p.y < img.H
      );

      this.prevKeys = new Uint32Array(
        this.stations.length
      );

      rebuilt = true;
    }

    const changed = [];

    const n = this.stations.length;
    const pal = img.pal;

    for (let i = 0; i < n; i++) {
      const s = this.stations[i];

      const col = s.x - img.left;
      const row = s.y - img.top;

      let key = 0;

      if (
        col >= 0 &&
        row >= 0 &&
        col < img.w &&
        row < img.h
      ) {
        const ci =
          img.px[
            img.rowPos[row] * img.w + col
          ];

        if (
          ci !== img.trans &&
          pal &&
          ci * 3 + 2 < pal.length
        ) {
          const o = ci * 3;

          key = (
            (1 << 24) |
            (pal[o] << 16) |
            (pal[o + 1] << 8) |
            pal[o + 2]
          ) >>> 0;
        }
      }

      if (key !== this.prevKeys[i]) {
        this.prevKeys[i] = key;
        changed.push(i);
      }
    }

    this.lastMs = usedMs;

    const frame = rebuilt
      ? this.buildFrame(
          this.fullIndices(),
          true,
          clientCount
        )
      : this.buildFrame(
          changed,
          false,
          clientCount
        );

    this.broadcastBinary(frame);

    this.lastBroadcastMs = Date.now();
    this.lastSuccessMs = this.lastBroadcastMs;

    this.lastProcessMs = Date.now() - t0;
  }

  fullIndices() {
    const out = [];

    for (
      let i = 0;
      i < this.prevKeys.length;
      i++
    ) {
      if (this.prevKeys[i] !== 0) {
        out.push(i);
      }
    }

    return out;
  }

  buildFrame(indices, full, clientCount) {
    const count = indices.length;

    const out = new Uint8Array(
      22 + count * 6
    );

    const dv = new DataView(out.buffer);

    dv.setUint8(0, 1);

    dv.setFloat64(
      1,
      this.lastMs,
      true
    );

    dv.setUint16(9, this.w, true);
    dv.setUint16(11, this.h, true);

    dv.setUint8(
      13,
      full ? 1 : 0
    );

    dv.setUint16(
      14,
      this.stations.length,
      true
    );

    dv.setUint16(
      16,
      count,
      true
    );

    dv.setUint16(
      18,
      Math.min(this.serverMs, 65535),
      true
    );

    dv.setUint16(
      20,
      clientCount ?? clients.size,
      true
    );

    let o = 22;

    for (let k = 0; k < count; k++) {
      const i = indices[k];
      const key = this.prevKeys[i];

      dv.setUint16(o, i, true);

      out[o + 2] = key ? 1 : 0;

      out[o + 3] = (key >> 16) & 255;
      out[o + 4] = (key >> 8) & 255;
      out[o + 5] = key & 255;

      o += 6;
    }

    return out;
  }

  broadcastBinary(data) {
    for (const ws of clients) {
      if (ws.readyState !== WebSocket.OPEN) {
        continue;
      }

      try {
        ws.send(data, {
          binary: true
        });
      } catch {}
    }
  }

  broadcastText(text) {
    for (const ws of clients) {
      if (ws.readyState !== WebSocket.OPEN) {
        continue;
      }

      try {
        ws.send(text);
      } catch {}
    }
  }

  async fetchLatest() {
    const res = await fetch(
      LATEST_URL + '?_=' + Date.now(),
      {
        signal: AbortSignal.timeout(
          LATEST_TIMEOUT
        ),

        cache: 'no-store',

        headers: {
          'Cache-Control':
            'no-cache, no-store, max-age=0',

          'Pragma': 'no-cache'
        }
      }
    );

    if (!res.ok) {
      throw new Error(
        'latest.json HTTP ' + res.status
      );
    }

    const raw = await res.text();

    let data;

    try {
      data = JSON.parse(
        raw.replace(/^\uFEFF/, '')
      );

    } catch {
      throw new Error(
        'latest.jsonのJSON解析に失敗しました'
      );
    }

    return findLatestTime(data);
  }

  async loadPoints() {
    if (this.points) {
      return this.points;
    }

    if (this.pointsPromise) {
      return this.pointsPromise;
    }

    this.pointsPromise = (async () => {
      try {
        const res = await fetch(
          POINTS_URL,
          {
            signal: AbortSignal.timeout(8000),

            headers: {
              'Cache-Control': 'no-cache'
            }
          }
        );

        if (!res.ok) {
          throw new Error(
            '観測点JSON HTTP ' + res.status
          );
        }

        const raw = await res.text();

        const data = JSON.parse(
          raw.replace(/^\uFEFF/, '')
        );

        const recs = walkRecords(data);

        if (!recs.length) {
          throw new Error(
            '観測点データが見つかりません'
          );
        }

        const prepared = preparePoints(recs);

        if (!prepared.length) {
          throw new Error(
            '有効な観測点がありません'
          );
        }

        this.points = prepared;

        return prepared;

      } catch (e) {
        this.pointsPromise = null;
        throw e;
      }
    })();

    return this.pointsPromise;
  }
}

// Collectorクラス宣言後に初期化する
const collector = new Collector();
const collectorInstance = collector;

wss.on('connection', ws => {
  clients.add(ws);

  console.log(
    new Date().toISOString(),
    `WSS接続: ${clients.size} clients`
  );

  if (
    collectorInstance.lastMs &&
    collectorInstance.stations.length
  ) {
    try {
      ws.send(
        collectorInstance.buildFrame(
          collectorInstance.fullIndices(),
          true,
          clients.size
        ),
        {
          binary: true
        }
      );

    } catch {}
  }

  collectorInstance.start();

  ws.on('message', () => {
    // ping等の受信
  });

  ws.on('close', () => {
    clients.delete(ws);

    console.log(
      new Date().toISOString(),
      `WSS切断: ${clients.size} clients`
    );

    collectorInstance.stopIfIdle();
  });

  ws.on('error', err => {
    console.warn(
      'WebSocket error:',
      err.message
    );
  });
});

server.listen(PORT, HOST, () => {
  console.log(
    `Node collector listening on http://${HOST}:${PORT}`
  );

  console.log(
    `Status: http://${HOST}:${PORT}/status`
  );

  console.log(
    '閲覧者が接続すると取得を開始し、0人になると停止します。'
  );
});

function shutdown() {
  console.log('サーバーを終了します...');

  if (collectorInstance.timer !== null) {
    clearTimeout(collectorInstance.timer);
  }

  collectorInstance.timer = null;
  collectorInstance.nextPollAt = 0;

  for (const ws of clients) {
    try {
      ws.close(1001, 'server shutdown');
    } catch {}
  }

  server.close(() => {
    process.exit(0);
  });

  setTimeout(() => {
    process.exit(1);
  }, 5000).unref();
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

const p2 = n =>
  String(n).padStart(2, '0');

function imageUrlFor(ms) {
  const d = new Date(ms + 9 * 3600e3);

  const Y = d.getUTCFullYear();
  const M = p2(d.getUTCMonth() + 1);
  const D = p2(d.getUTCDate());

  const h = p2(d.getUTCHours());
  const m = p2(d.getUTCMinutes());
  const s = p2(d.getUTCSeconds());

  return (
    `${BASE_URL}${Y}${M}${D}/` +
    `${Y}${M}${D}${h}${m}${s}.jma_s.gif`
  );
}

function parseTimeValue(value) {
  if (typeof value === 'number') {
    if (value > 1000000000000) {
      return value;
    }

    if (value > 1000000000) {
      return value * 1000;
    }

    return null;
  }

  if (typeof value !== 'string') {
    return null;
  }

  const s = value.trim();

  if (/^\d{14}$/.test(s)) {
    const iso =
      `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}T` +
      `${s.slice(8, 10)}:${s.slice(10, 12)}:${s.slice(12, 14)}+09:00`;

    const ms = Date.parse(iso);

    return Number.isFinite(ms) ? ms : null;
  }

  const compact = s.match(
    /(\d{4})[/-](\d{2})[/-](\d{2})[ T](\d{2}):(\d{2}):(\d{2})/
  );

  if (compact) {
    const iso =
      `${compact[1]}-${compact[2]}-${compact[3]}T` +
      `${compact[4]}:${compact[5]}:${compact[6]}+09:00`;

    const ms = Date.parse(iso);

    return Number.isFinite(ms) ? ms : null;
  }

  if (/^\d{10,13}$/.test(s)) {
    const n = Number(s);

    if (n > 1000000000000) {
      return n;
    }

    if (n > 1000000000) {
      return n * 1000;
    }
  }

  return null;
}

function findLatestTime(data) {
  const candidates = [];

  function walk(value, key = '') {
    if (
      value === null ||
      value === undefined
    ) {
      return;
    }

    if (typeof value === 'object') {
      if (Array.isArray(value)) {
        for (const item of value) {
          walk(item, key);
        }

      } else {
        for (const [k, v] of Object.entries(value)) {
          walk(v, k);
        }
      }

      return;
    }

    const ms = parseTimeValue(value);

    if (ms === null) {
      return;
    }

    const name = String(key).toLowerCase();

    let priority = 0;

    if (name.includes('latest')) priority += 10;
    if (name.includes('time')) priority += 5;
    if (name.includes('date')) priority += 3;

    candidates.push({
      ms,
      priority
    });
  }

  walk(data);

  if (!candidates.length) {
    throw new Error(
      'latest.json内に認識可能な時刻がありません'
    );
  }

  candidates.sort((a, b) =>
    b.priority !== a.priority
      ? b.priority - a.priority
      : b.ms - a.ms
  );

  return candidates[0].ms;
}

function walkRecords(value, out = []) {
  if (Array.isArray(value)) {
    for (const v of value) {
      walkRecords(v, out);
    }

    return out;
  }

  if (value && typeof value === 'object') {
    if (
      value.location &&
      value.point &&
      value.point.center_point
    ) {
      out.push(value);
    }

    for (const v of Object.values(value)) {
      if (v && typeof v === 'object') {
        walkRecords(v, out);
      }
    }
  }

  return out;
}

function preparePoints(recs) {
  const result = [];

  for (const item of recs) {
    const loc = item.location || {};
    const point = item.point || {};

    const center = point.center_point || {};
    const offset = point.offset || {};

    const lat = Number(loc.latitude);
    const lon = Number(loc.longitude);

    const x =
      Number(center.x) +
      Number(offset.x || 0);

    const y =
      Number(center.y) +
      Number(offset.y || 0);

    if (
      !Number.isFinite(lat) ||
      !Number.isFinite(lon) ||
      !Number.isFinite(x) ||
      !Number.isFinite(y)
    ) {
      continue;
    }

    if (item.is_suspended === true) {
      continue;
    }

    result.push({
      x: Math.round(x),
      y: Math.round(y)
    });
  }

  return result;
}

function decodeGif(buf) {
  const u16 = p =>
    buf[p] | (buf[p + 1] << 8);

  if (
    buf[0] !== 0x47 ||
    buf[1] !== 0x49 ||
    buf[2] !== 0x46
  ) {
    throw new Error('GIFではありません');
  }

  const W = u16(6);
  const H = u16(8);

  const gf = buf[10];

  let p = 13;
  let gct = null;

  if (gf & 0x80) {
    const n = 3 * (2 << (gf & 7));

    gct = buf.subarray(p, p + n);

    p += n;
  }

  let trans = -1;

  while (p < buf.length) {
    const b = buf[p++];

    if (b === 0x21) {
      const label = buf[p++];

      if (label === 0xf9 && buf[p] >= 4) {
        if (buf[p + 1] & 1) {
          trans = buf[p + 4];
        }
      }

      let sz;

      while (
        p < buf.length &&
        (sz = buf[p++]) !== 0
      ) {
        p += sz;
      }

    } else if (b === 0x2c) {
      const left = u16(p);
      const top = u16(p + 2);

      const w = u16(p + 4);
      const h = u16(p + 6);

      const f = buf[p + 8];

      p += 9;

      let pal = gct;

      if (f & 0x80) {
        const n = 3 * (2 << (f & 7));

        pal = buf.subarray(p, p + n);

        p += n;
      }

      const minCode = buf[p++];

      let total = 0;
      let q = p;
      let sz;

      while (
        q < buf.length &&
        (sz = buf[q++]) !== 0
      ) {
        total += sz;
        q += sz;
      }

      const data = new Uint8Array(total);

      let dp = 0;
      q = p;

      while (
        q < buf.length &&
        (sz = buf[q++]) !== 0
      ) {
        data.set(
          buf.subarray(q, q + sz),
          dp
        );

        dp += sz;
        q += sz;
      }

      const px = new Uint8Array(w * h);

      lzwDecode(minCode, data, px);

      const rowPos = new Uint16Array(h);

      if (f & 0x40) {
        let d = 0;

        for (const [start, step] of [
          [0, 8],
          [4, 8],
          [2, 4],
          [1, 2]
        ]) {
          for (
            let r = start;
            r < h;
            r += step
          ) {
            rowPos[r] = d++;
          }
        }

      } else {
        for (let r = 0; r < h; r++) {
          rowPos[r] = r;
        }
      }

      return {
        W,
        H,
        left,
        top,
        w,
        h,
        pal,
        trans,
        px,
        rowPos
      };

    } else if (b === 0x3b) {
      break;

    } else {
      throw new Error('不明なGIFブロック');
    }
  }

  throw new Error('GIF画像データがありません');
}

function lzwDecode(minCode, data, out) {
  const clear = 1 << minCode;
  const eoi = clear + 1;

  let size = minCode + 1;
  let mask = (1 << size) - 1;

  let next = eoi + 1;

  const prefix = new Uint16Array(4096);
  const suffix = new Uint8Array(4096);
  const stack = new Uint8Array(4097);

  for (let c = 0; c < clear; c++) {
    suffix[c] = c;
  }

  const n = out.length;

  let bits = 0;
  let datum = 0;

  let ip = 0;
  let op = 0;

  let old = -1;
  let first = 0;

  while (op < n) {
    while (bits < size) {
      if (ip >= data.length) {
        return op;
      }

      datum |= data[ip++] << bits;
      bits += 8;
    }

    let code = datum & mask;

    datum >>= size;
    bits -= size;

    if (code === clear) {
      size = minCode + 1;
      mask = (1 << size) - 1;

      next = eoi + 1;
      old = -1;

      continue;
    }

    if (code === eoi) {
      break;
    }

    if (old === -1) {
      out[op++] = suffix[code];

      old = code;
      first = code;

      continue;
    }

    const inCode = code;

    let sp = 0;

    if (code >= next) {
      stack[sp++] = first;
      code = old;
    }

    while (code >= clear) {
      stack[sp++] = suffix[code];
      code = prefix[code];
    }

    first = suffix[code];

    stack[sp++] = first;

    if (next < 4096) {
      prefix[next] = old;
      suffix[next] = first;

      next++;

      if (
        (next & mask) === 0 &&
        next < 4096
      ) {
        size++;
        mask = (1 << size) - 1;
      }
    }

    old = inCode;

    while (sp > 0 && op < n) {
      out[op++] = stack[--sp];
    }
  }

  return op;
}