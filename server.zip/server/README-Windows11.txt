強震モニタ Node.js 本番サーバー（Windows 11）

1. ZIPを C:\KyoshinServer に展開
2. PowerShellを開き、次を実行
   cd C:\KyoshinServer
   npm.cmd install
3. 起動
   npm.cmd start
4. 稼働状態
   http://127.0.0.1:8787/status

サーバーは127.0.0.1:8787で待ち受けます。外部公開はCloudflare Tunnelを設定してから行います。
Tunnelの公開ホスト名はまだ確定していないため、HTML内のWS_URLは現行workers.devのままです。
公開URLが決まった段階で、既存HTMLのWS_URLを wss://公開ホスト名/ に変更してください。

取得仕様：閲覧者が接続している間だけ500ms間隔を目標に取得し、閲覧者0人で停止します。
取得元の応答遅延やアクセス制限により500msを超える場合があります。
