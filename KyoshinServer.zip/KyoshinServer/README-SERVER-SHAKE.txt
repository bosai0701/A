EQ-RTS Server - C# shake detection port

This package replaces the previous independent detector with a JavaScript port
of the uploaded KyoshinEewViewer source files:
- ShakeDetectionEngine.cs
- RealtimeObservationPoint.cs
- KyoshinEvent.cs (including KyoshinEventLevel)
- ShakeDetectionParameters.cs

Important:
- Server-side detection continues independently of browser page reloads.
- Only confirmed events are included in shake_state broadcasts.
- The HTML also filters out any event whose c flag is not 1.
- The previous baseline-learning, median/MAD, and multi-frame persistence
  algorithm has been removed.
- The original image-to-intensity conversion already present in this Node
  collector (hsvPos / pos * 10 - 3) has been retained. It is not a direct
  port of KyoshinEewViewer's ColorConverter implementation because that
  converter source was not part of the supplied files. Detector decisions
  therefore follow the C# engine logic for the values supplied to it, while
  exact pixel-to-intensity equivalence is not asserted.

Run:
  npm install
  npm start

Default local address:
  http://127.0.0.1:8787
  WebSocket endpoint: ws://127.0.0.1:8787

Use your existing secure tunnel/reverse proxy to expose WSS when required.
