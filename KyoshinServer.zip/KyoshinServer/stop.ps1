$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
foreach ($name in @("cloudflared.pid", "node.pid")) {
    $file = Join-Path $root $name
    if (Test-Path $file) {
        $pidText = Get-Content $file -ErrorAction SilentlyContinue
        if ($pidText -match '^\d+$') {
            Stop-Process -Id ([int]$pidText) -Force -ErrorAction SilentlyContinue
        }
        Remove-Item $file -Force -ErrorAction SilentlyContinue
    }
}
Write-Host "EQ-RTSの起動プロセスを停止しました。"
