# EQ-RTS — Server-side image analysis + WSS

## 処理構成

1. `server.js` が気象庁・防災科研の強震モニタ最新時刻情報を取得します。
2. 自宅PC上で強震モニタGIFを取得・デコードします。
3. 観測点JSONの画像座標から各観測点の画素色を取り出し、リアルタイム震度相当値を計算します。
4. サーバー上で10件履歴・近傍距離重み・異常値除外・イベント統合・確定判定を実行します。
5. 同じWebSocket接続で、観測点リストと差分フレーム（バイナリ）、揺れ検知状態（JSON）をブラウザへ配信します。
6. `index.html` は受信した強震モニタ観測点をMapLibre地図に描画し、揺れ検知地点・範囲を重ねて表示します。検知計算はブラウザでは行いません。

## ファイル

- `server.js` — 画像取得、GIF解析、観測点色抽出、揺れ検知、HTTP/WSS配信
- `index.html` — 地図表示とWSSクライアント
- `csharp-source/` — 元の検知アルゴリズム4ファイル
- `start.ps1` — Node.jsサーバーとCloudflare Quick Tunnelを起動
- `stop.ps1` — 起動したプロセスを停止
- `package.json`, `package-lock.json` — Node.js依存関係

## Windowsでの起動

1. ZIPを任意のフォルダ（例 `C:\\KyoshinServer`）へ展開します。
2. Node.jsをインストールします。
3. `cloudflared.exe`（または `cloudflared-windows-amd64.exe`）を同じフォルダに置きます。
4. PowerShellで展開先へ移動し、次を実行します。

```powershell
powershell -ExecutionPolicy Bypass -File .\\start.ps1
```

5. 表示された「サイト URL」を開きます。サイトとWSSは同じホストを使うため、URLの手動書き換えやGitHub認証は不要です。
6. 終了時は `stop.ps1` を実行します。

## 状態確認

- ローカル: `http://127.0.0.1:8787/status`
- 外部: 起動時に表示されたURLの末尾に `/status` を付けます。

主な項目:

- `lastErr` — 時刻・画像・観測点データ取得等のエラー
- `lastImageJST` — 最後に解析した画像時刻
- `lastFreshIntensityCount` — 直近画像で震度値を抽出できた観測点数
- `lastValidHistoryCount` — 有効履歴を持つ観測点数
- `detection.confirmed` / `detection.pending` — 確定・未確定イベント数
- `detection.lastDetectError` — 検知処理エラー

## 表示・検知上の注意

- 観測点の表示保持時間は5秒です。新しい有効画素が届かない地点は5秒後に表示から消えます。
- 未確定イベントは破線・薄いリングで表示し、確定イベントと区別します。自動ズームは確定イベントのみ対象です。
- 検知ロジックのパラメータとイベント処理は、同梱C#ソースを基準にJavaScriptへ移植しています。
- 色→スケール変換も `KyoshinMonitorLib.SkiaImages.ColorConverter` のHSV計算とHorner法をJavaScriptへ移植しています。不透明な非震度色はスケール0（震度相当値-3）として履歴に入り、透明画素だけを欠測として扱います。これはC#側の `Alpha != 255` 判定と `ColorConverter` の戻り値に合わせた修正です。
- 色変換コードの参照元は `https://github.com/ingen084/KyoshinMonitorLib`（MIT License、取得したソースのコミット `ce56bb7ab7b2cb250fdbfae03160213e528657bd`）です。
- 実際の揺れがないときに検知を試験する目的で、検知閾値を勝手に緩めないでください。まず `/status` の画像取得・有効観測点数・履歴数を確認してください。

## 通信

- ブラウザ表示: HTTPS
- ブラウザからサーバー: WSS
- バイナリ: 強震モニタ観測点の色・有効状態のフレーム
- JSON: `stations`, `shake_state`, `error`

Quick TunnelのURLは起動ごとに変わる場合があります。毎回 `start.ps1` が表示したURLを使用してください。
