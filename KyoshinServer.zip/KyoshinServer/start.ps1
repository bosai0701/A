
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$repo = "bosai0701/eq-rts"
$branch = "main"

$serverPath = Join-Path $root "server.js"
$tunnelPath = Join-Path $root "cloudflared.exe"

$nodeLog = Join-Path $root "node.log"
$nodeError = Join-Path $root "node-error.log"
$tunnelLog = Join-Path $root "tunnel.log"
$tunnelError = Join-Path $root "tunnel-error.log"

$node = (Get-Command node.exe -ErrorAction Stop).Source
$npm = (Get-Command npm.cmd -ErrorAction Stop).Source
$gh = (Get-Command gh.exe -ErrorAction Stop).Source

if (!(Test-Path $serverPath)) {
    throw "server.js がありません"
}

if (!(Test-Path $tunnelPath)) {
    throw "cloudflared.exe がありません"
}

& $gh auth status
if ($LASTEXITCODE -ne 0) {
    throw "GitHub CLIの認証が必要です。gh auth login を実行してください"
}

Write-Host "依存関係を確認しています..."

if (!(Test-Path (Join-Path $root "node_modules/ws"))) {
    Push-Location $root
    try {
        & $npm install
        if ($LASTEXITCODE -ne 0) {
            throw "npm install に失敗しました"
        }
    }
    finally {
        Pop-Location
    }
}

Write-Host "Node.js Serverを確認しています..."

$serverReady = $false

try {
    Invoke-RestMethod "http://127.0.0.1:8787/status" -TimeoutSec 2 | Out-Null
    $serverReady = $true
}
catch {}

if (!$serverReady) {
    Start-Process `
        -FilePath $node `
        -ArgumentList "server.js" `
        -WorkingDirectory $root `
        -WindowStyle Hidden `
        -RedirectStandardOutput $nodeLog `
        -RedirectStandardError $nodeError

    for ($i = 0; $i -lt 30; $i++) {
        Start-Sleep -Seconds 1

        try {
            Invoke-RestMethod "http://127.0.0.1:8787/status" -TimeoutSec 2 | Out-Null
            $serverReady = $true
            break
        }
        catch {}
    }
}

if (!$serverReady) {
    throw "Node.js Serverの起動に失敗しました。node-error.logを確認してください"
}

Write-Host "Node.js Server OK"

Write-Host "Cloudflare Tunnelを起動しています..."

$oldPidFile = Join-Path $root "cloudflared.pid"

if (Test-Path $oldPidFile) {
    $oldPid = Get-Content $oldPidFile -ErrorAction SilentlyContinue

    if ($oldPid -match '^\d+$') {
        $oldProcess = Get-Process -Id ([int]$oldPid) -ErrorAction SilentlyContinue

        if ($oldProcess -and $oldProcess.ProcessName -eq "cloudflared") {
            Stop-Process -Id ([int]$oldPid) -Force
        }
    }
}

Remove-Item $tunnelLog, $tunnelError -Force -ErrorAction SilentlyContinue

$tunnelProcess = Start-Process `
    -FilePath $tunnelPath `
    -ArgumentList @(
        "tunnel",
        "--url",
        "http://127.0.0.1:8787",
        "--no-autoupdate"
    ) `
    -WorkingDirectory $root `
    -PassThru `
    -WindowStyle Hidden `
    -RedirectStandardOutput $tunnelLog `
    -RedirectStandardError $tunnelError

Set-Content $oldPidFile $tunnelProcess.Id

$httpsUrl = $null

for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Seconds 1

    if ($tunnelProcess.HasExited) {
        throw "Cloudflare Tunnelが終了しました。tunnel-error.logを確認してください"
    }

    $logs = ""

    foreach ($file in @($tunnelLog, $tunnelError)) {
        if (Test-Path $file) {
            $logs += Get-Content $file -Raw -ErrorAction SilentlyContinue
        }
    }

    $match = [regex]::Match(
        $logs,
        'https://[a-z0-9-]+\.trycloudflare\.com',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )

    if ($match.Success) {
        $httpsUrl = $match.Value
        break
    }
}

if (!$httpsUrl) {
    throw "Cloudflare TunnelのURLを取得できませんでした"
}

$wsUrl = ($httpsUrl -replace '^https://', 'wss://') + "/"

Write-Host "取得したWSS URL: $wsUrl"

Write-Host "GitHub Pagesの既存HTMLを取得しています..."

$file = & $gh api "repos/$repo/contents/index.html?ref=$branch" |
    ConvertFrom-Json

if ($LASTEXITCODE -ne 0) {
    throw "GitHubからindex.htmlを取得できませんでした"
}

$bytes = [Convert]::FromBase64String(
    ($file.content -replace '\s', '')
)

$html = [System.Text.Encoding]::UTF8.GetString($bytes)

$pattern = '(?m)(const\s+WS_URL\s*=\s*\r?\n\s*)[''"][^''"]*[''"]\s*;'
$regex = [regex]::new($pattern)

if ($regex.Matches($html).Count -ne 1) {
    throw "WS_URLが1つだけ見つかりません。GitHubのHTMLは変更していません"
}

$html = $regex.Replace(
    $html,
    [System.Text.RegularExpressions.MatchEvaluator]{
        param($m)
        return $m.Groups[1].Value + "'" + $wsUrl + "';"
    },
    1
)

Write-Host "WebSocket URLだけを更新しています..."

$newBytes = [System.Text.Encoding]::UTF8.GetBytes($html)
$encoded = [Convert]::ToBase64String($newBytes)

$payload = @{
    message = "Update EQ-RTS WebSocket URL"
    content = $encoded
    sha = $file.sha
    branch = $branch
} | ConvertTo-Json -Compress

$tempJson = Join-Path $root "github-update.json"

[System.IO.File]::WriteAllText(
    $tempJson,
    $payload,
    [System.Text.UTF8Encoding]::new($false)
)

try {
    & $gh api `
        --method PUT `
        "repos/$repo/contents/index.html" `
        --input $tempJson | Out-Null

    if ($LASTEXITCODE -ne 0) {
        throw "GitHubのHTML更新に失敗しました"
    }
}
finally {
    Remove-Item $tempJson -Force -ErrorAction SilentlyContinue
}

Write-Host ""
Write-Host "===================================="
Write-Host "EQ-RTS Server 起動処理完了"
Write-Host "===================================="
Write-Host "GitHub Pages URL: 変更していません"
Write-Host "WebSocket URL: $wsUrl"
Write-Host "Status URL: $httpsUrl/status"
Write-Host "===================================="
