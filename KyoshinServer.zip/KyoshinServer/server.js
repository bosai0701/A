import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { performance } from 'node:perf_hooks';
import { WebSocketServer, WebSocket } from 'ws';

const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 8787);

const BASE_URL =
  'http://www.kmoni.bosai.go.jp/data/map_img/RealTimeImg/jma_s/';

const LATEST_URL =
  'http://www.kmoni.bosai.go.jp/webservice/server/pros/latest.json';

const POINTS_URL =
  'https://raw.githubusercontent.com/ingen084/kyoshin-monitor-observation-points/refs/heads/master/intensity-points.json';

const POLL_MS = 750;
const FALLBACK_SECONDS = 3;
const FETCH_TIMEOUT = 5000;
const LATEST_TIMEOUT = 5000;

// 新しい有効データが来なくなった観測点を表示から消すまでの保持時間
const DISPLAY_HOLD_MS = 3000;

// 接続が無反応のクライアントを切るまでの間隔
const WS_PING_MS = 30000;
const WS_MAX_BUFFER = 4 * 1024 * 1024;

const ALLOWED_ORIGINS = [];

const APP_DIR = path.dirname(fileURLToPath(import.meta.url));
const INDEX_FILE = path.join(APP_DIR, 'index.html');

function formatJST(ms) {
  if (!ms) return null;

  return new Date(ms + 9 * 3600e3)
    .toISOString()
    .replace('T', ' ')
    .slice(0, 19) + ' JST';
}

const RAD = Math.PI / 180;

function hsvPos(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let h = 0;
  const v = mx, sat = mx === 0 ? 0 : d / mx;
  if (d) {
    if (mx === r) { h = (g - b) / d; if (g < b) h += 6; }
    else if (mx === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h /= 6;
  }
  if (!(v > 0.1 && sat > 0.75)) return null;
  let p;
  if (h > 0.1476) {
    const h2 = h * h, h3 = h2 * h, h4 = h3 * h, h5 = h4 * h, h6 = h5 * h;
    p = 280.31*h6 - 916.05*h5 + 1142.6*h4 - 709.95*h3 + 234.65*h2 - 40.27*h + 3.2217;
  } else if (h > 0.001) {
    const h2 = h*h, h3 = h2*h, h4 = h3*h;
    p = 151.4*h4 - 49.32*h3 + 6.753*h2 - 2.481*h + 0.9033;
  } else {
    p = -0.005171*v*v - 0.3282*v + 1.2236;
  }
  return Number.isFinite(p) ? Math.max(0, p) : null;
}

/* ========================================================================
 * 揺れ検知エンジン
 * ShakeDetectionEngine / RealtimeObservationPoint / KyoshinEvent /
 * ShakeDetectionParameters のロジックをサーバー側へ移植
 * ====================================================================== */

const DEG2RAD = Math.PI / 180;

const SD = Object.freeze({
  MaxSearchDistance: 60.0,
  PeakWeightDistance: 14.0,
  IsolatedThreshold: 1,
  IsolatedDetectionDiff: 1.4,
  ScoreThresholdRatio: 0.333333,
  ScoreIntensityOffset: -0.8,
  MinDetectionDiff: 0.2,
  NoChangePenaltyFactor: 0.25,
  MaxNearPoints: 50,
  StrongerMergeDistance: 250.0,
  StrongMergeDistance: 250.0,
  MediumMergeDistance: 180.0,
  WeakMergeDistance: 130.0,
  WeakerMergeDistance: 90.0,
  StrongerSeconds: 80,
  StrongSeconds: 70,
  MediumSeconds: 40,
  WeakSeconds: 30,
  WeakerSeconds: 20,
  WeakerConfirmPointCount: 4,
  WeakConfirmPointCount: 3
});

const LV_WEAKER = 0;
const LV_WEAK = 1;
const LV_MEDIUM = 2;
const LV_STRONG = 3;
const LV_STRONGER = 4;

function geoDistance(lat1, lon1, lat2, lon2) {
  const dLat = (lat2 - lat1) * DEG2RAD;
  const dLon = (lon2 - lon1) * DEG2RAD;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * DEG2RAD) *
    Math.cos(lat2 * DEG2RAD) *
    Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.min(1, Math.sqrt(a)));
}

function getLevel(intensity) {
  if (intensity !== null && intensity !== undefined && intensity > 4.5) return LV_STRONGER;
  if (intensity !== null && intensity !== undefined && intensity > 2.5) return LV_STRONG;
  if (intensity !== null && intensity !== undefined && intensity > 0.5) return LV_MEDIUM;
  if (intensity !== null && intensity !== undefined && intensity > -1) return LV_WEAK;
  return LV_WEAKER;
}

function getSeconds(level) {
  switch (level) {
    case LV_STRONGER: return SD.StrongerSeconds;
    case LV_STRONG: return SD.StrongSeconds;
    case LV_MEDIUM: return SD.MediumSeconds;
    case LV_WEAK: return SD.WeakSeconds;
    default: return SD.WeakerSeconds;
  }
}

function getMergeDistance(level) {
  switch (level) {
    case LV_STRONGER: return SD.StrongerMergeDistance;
    case LV_STRONG: return SD.StrongMergeDistance;
    case LV_MEDIUM: return SD.MediumMergeDistance;
    case LV_WEAK: return SD.WeakMergeDistance;
    default: return SD.WeakerMergeDistance;
  }
}

function calculateDistanceWeight(distance) {
  if (distance <= SD.PeakWeightDistance) {
    return distance / SD.PeakWeightDistance;
  }
  return (SD.MaxSearchDistance - distance) /
    (SD.MaxSearchDistance - SD.PeakWeightDistance);
}

class ShakeEvent {
  constructor(time, firstPoint, expireSeconds) {
    this.id = crypto.randomUUID();
    this.level = getLevel(firstPoint.latest);
    this.createdAt = time;
    this.points = [firstPoint];
    this.isConfirmed = false;
    this.topLeft = { lat: firstPoint.lat, lon: firstPoint.lon };
    this.bottomRight = { lat: firstPoint.lat, lon: firstPoint.lon };
    firstPoint.eventedAt = time;
    const expireAt = time + expireSeconds * 1000;
    if (firstPoint.eventedExpireAt < expireAt) {
      firstPoint.eventedExpireAt = expireAt;
    }
  }

  get pointCount() {
    return this.points.length;
  }

  addPoint(point, time, expireSeconds) {
    const level = getLevel(point.latest);

    // 原典と同じく、同じレベル以上の既存観測点がある場合のみレベルを上げる
    if (this.level < level && this.points.some(p => getLevel(p.latest) >= level)) {
      this.level = level;
    }

    if (level === this.level) {
      // 地域リストは配信HTMLで使用しないため内部状態には保持しない
    }

    point.eventedAt = time;
    const expireAt = time + expireSeconds * 1000;
    if (point.eventedExpireAt < expireAt) point.eventedExpireAt = expireAt;

    if (this.points.includes(point)) return;

    this.topLeft.lat = Math.min(this.topLeft.lat, point.lat);
    this.topLeft.lon = Math.min(this.topLeft.lon, point.lon);
    this.bottomRight.lat = Math.max(this.bottomRight.lat, point.lat);
    this.bottomRight.lon = Math.max(this.bottomRight.lon, point.lon);

    point.event = this;
    this.points.push(point);
  }

  mergeEvent(evt) {
    for (const point of evt.points) point.event = this;

    if (this.level < evt.level) this.level = evt.level;

    this.topLeft.lat = Math.min(this.topLeft.lat, evt.topLeft.lat);
    this.topLeft.lon = Math.min(this.topLeft.lon, evt.topLeft.lon);
    this.bottomRight.lat = Math.max(this.bottomRight.lat, evt.bottomRight.lat);
    this.bottomRight.lon = Math.max(this.bottomRight.lon, evt.bottomRight.lon);

    this.points.push(...evt.points);
  }

  removePoint(point) {
    const index = this.points.indexOf(point);
    if (index < 0) return;
    point.event = null;
    point.eventedExpireAt = 0;
    this.points.splice(index, 1);
  }

  checkNearby(evt, distance) {
    return this.points.some(p1 =>
      evt.points.some(p2 =>
        geoDistance(p1.lat, p1.lon, p2.lat, p2.lon) <= distance
      )
    );
  }
}

class ShakeDetector {
  constructor() {
    this.points = [];
    this.events = [];
    this.lastMs = null;
  }

  initialize(sourcePoints) {
    this.points = sourcePoints.map((source, index) => ({
      index,
      lat: source.lat,
      lon: source.lon,
      code: source.code || "",
      name: source.name || "",

      // RealtimeObservationPoint の10件循環履歴
      history: new Array(10).fill(null),
      historyPosition: 0,
      latest: null,
      intensityDiff: 0,
      intensityAverage: 0,
      hasValidHistory: false,
      tmpDisabled: false,

      near: [],
      event: null,
      eventedAt: 0,
      eventedExpireAt: 0
    }));

    this.setupNearPoints();
    this.events = [];
    this.lastMs = null;
  }

  setupNearPoints() {
    for (const point of this.points) {
      point.near = this.points
        .filter(other => other !== point)
        .map(other => ({
          point: other,
          distance: geoDistance(point.lat, point.lon, other.lat, other.lon)
        }))
        .filter(item => item.distance < SD.MaxSearchDistance)
        .sort((a, b) => a.distance - b.distance)
        .slice(0, SD.MaxNearPoints)
        .map(item => ({
          point: item.point,
          distance: item.distance,
          weight: calculateDistanceWeight(item.distance)
        }));
    }
  }

  updatePoint(point, intensity) {
    // C# LatestIntensity setter: 値が null の場合も履歴位置を進める
    if (point.historyPosition + 1 >= 10) point.historyPosition = 0;
    else point.historyPosition++;

    point.history[point.historyPosition] = intensity;
    point.latest = point.history[point.historyPosition];

    let before = null;
    let diff = 0;
    let total = 0;

    for (let i = point.historyPosition; i >= 0; i--) {
      const value = point.history[i];
      if (value !== null && value !== undefined) {
        if (before !== null) diff += before - value;
        before = value;
        total += value;
      }
    }

    for (let i = 9; i > point.historyPosition; i--) {
      const value = point.history[i];
      if (value !== null && value !== undefined) {
        if (before !== null) diff += before - value;
        before = value;
        total += value;
      }
    }

    point.intensityDiff = diff;
    point.intensityAverage = total / 10;

    // C# Update(color, intensity): 一度有効な色・震度を得た後は true を維持
    if (intensity !== null && intensity !== undefined) {
      point.hasValidHistory = true;
    }
  }

  resetHistories() {
    for (const point of this.points) {
      point.history.fill(null);
      point.historyPosition = 0;
      point.latest = null;
      point.intensityDiff = 0;
      point.intensityAverage = 0;
      point.event = null;
      point.eventedExpireAt = 0;
    }
    this.events = [];
  }

  updateEventConfirmation(evt) {
    if (evt.isConfirmed) return;

    if (
      (evt.level <= LV_WEAKER && evt.pointCount > SD.WeakerConfirmPointCount) ||
      (evt.level === LV_WEAK && evt.pointCount > SD.WeakConfirmPointCount) ||
      evt.level > LV_WEAK
    ) {
      evt.isConfirmed = true;
    }
  }

  processEvents(time) {
    for (const point of this.points) {
      const latest = point.latest;
      const hasNear = point.near.length > 0;

      // ShakeDetectionEngine.cs の異常値除外条件
      if (
        latest !== null &&
        point.intensityDiff < 1 &&
        point.event === null &&
        latest >= (hasNear ? 3 : 5) &&
        Math.abs(point.intensityAverage - latest) <= 1 &&
        (
          point.tmpDisabled ||
          point.near.every(n =>
            latest - (n.point.latest === null ? -3 : n.point.latest) >= 3
          )
        )
      ) {
        point.tmpDisabled = true;
      } else if (latest !== null && point.tmpDisabled) {
        point.tmpDisabled = false;
      }

      if (point.tmpDisabled) continue;

      if (point.intensityDiff < SD.MinDetectionDiff) {
        if (
          point.event &&
          (point.eventedAt > time || point.eventedExpireAt < time)
        ) {
          const evt = point.event;
          point.event = null;
          evt.removePoint(point);

          if (evt.pointCount <= 0) {
            const index = this.events.indexOf(evt);
            if (index >= 0) this.events.splice(index, 1);
          }
        }
        continue;
      }

      if (!point.near || latest === null) continue;

      // C# 原典では tmpDisabled を除外せず、HasValidHistory のみで重み合計
      let availableTotalWeight = 0;
      for (const near of point.near) {
        if (near.point.hasValidHistory) availableTotalWeight += near.weight;
      }

      if (availableTotalWeight < SD.IsolatedThreshold) {
        if (
          point.intensityDiff >= SD.IsolatedDetectionDiff &&
          point.event === null
        ) {
          const level = getLevel(latest);
          const evt = new ShakeEvent(time, point, getSeconds(level));
          evt.isConfirmed = level > LV_WEAK;
          point.event = evt;
          point.eventedAt = time;
          this.events.push(evt);
        }
        continue;
      }

      const events = [];
      if (point.event !== null) events.push(point.event);

      let score = 0;
      let penaltyScore = 0;
      let contributingPointCount = 0;

      for (const near of point.near) {
        const neighbor = near.point;
        if (neighbor.tmpDisabled || !neighbor.hasValidHistory) continue;

        if (neighbor.intensityDiff >= SD.MinDetectionDiff) {
          score += near.weight *
            (neighbor.intensityDiff - SD.ScoreIntensityOffset);
          contributingPointCount++;
          if (neighbor.event !== null) events.push(neighbor.event);
        } else {
          penaltyScore += near.weight * SD.NoChangePenaltyFactor;
        }
      }

      const finalScore = score - penaltyScore;
      const threshold = availableTotalWeight * SD.ScoreThresholdRatio;

      if (contributingPointCount <= 1) continue;
      if (finalScore < threshold) continue;

      point.eventedAt = time;

      const uniqueEvents = [...new Set(events)];

      if (uniqueEvents.length > 1) {
        uniqueEvents.sort((a, b) => a.createdAt - b.createdAt);
        const firstEvent = uniqueEvents[0];

        for (const evt of uniqueEvents) {
          if (evt === firstEvent) continue;
          firstEvent.mergeEvent(evt);
          const index = this.events.indexOf(evt);
          if (index >= 0) this.events.splice(index, 1);
        }

        if (point.event === firstEvent) continue;

        firstEvent.addPoint(
          point,
          time,
          getSeconds(getLevel(point.latest))
        );
        this.updateEventConfirmation(firstEvent);
        continue;
      }

      if (uniqueEvents.length === 1) {
        uniqueEvents[0].addPoint(
          point,
          time,
          getSeconds(getLevel(point.latest))
        );
        this.updateEventConfirmation(uniqueEvents[0]);
        continue;
      }

      if (point.event === null) {
        const level = getLevel(point.latest);
        const evt = new ShakeEvent(time, point, getSeconds(level));
        point.event = evt;
        this.events.push(evt);
        this.updateEventConfirmation(evt);
      }
    }

    // 原典と同じ順序・距離でイベントを統合
    for (const evt of [...this.events].sort((a, b) => a.createdAt - b.createdAt)) {
      if (!this.events.includes(evt)) continue;

      const others = this.events.filter(
        other => other !== evt && evt.createdAt <= other.createdAt
      );

      for (const other of others) {
        if (!this.events.includes(other)) continue;

        const mergeDistance = getMergeDistance(
          evt.level > other.level ? evt.level : other.level
        );

        if (!evt.checkNearby(other, mergeDistance)) continue;

        evt.mergeEvent(other);
        const index = this.events.indexOf(other);
        if (index >= 0) this.events.splice(index, 1);
      }
    }
  }

  update(intensities, ms) {
    if (!this.points.length) return;
    if (this.lastMs === ms) return;
    this.lastMs = ms;

    for (const point of this.points) {
      const value = intensities[point.index];
      const intensity =
        value === undefined || value === null || !Number.isFinite(value)
          ? null
          : Math.fround(value);
      this.updatePoint(point, intensity);
    }

    this.processEvents(ms);
  }

  snapshot() {
    const events = [];

    // 未確定イベントはサーバーから配信しない
    for (const evt of this.events) {
      if (!evt.isConfirmed || evt.pointCount <= 0) continue;

      events.push({
        id: evt.id,
        c: 1,
        l: evt.level,
        pts: evt.points.map(point => [
          Math.round(point.lon * 1e4) / 1e4,
          Math.round(point.lat * 1e4) / 1e4,
          point.latest === null
            ? null
            : Math.round(point.latest * 10) / 10
        ])
      });
    }

    return {
      ms: this.lastMs,
      confirmed: events.length,
      pending: 0,
      events
    };
  }
}

const clients = new Set();

class Collector {
  constructor() {
    this.points = null;
    this.pointsPromise = null;

    this.stations = [];
    this.stationsJson = null;

    // 表示用の最終有効色（0 = 非表示）
    this.prevKeys = new Uint32Array(0);
    this.stationLastSeenMs = new Float64Array(0);

    this.stationPixelIndices = new Int32Array(0);
    this.pixelMapLeft = -1;
    this.pixelMapTop = -1;
    this.pixelMapWidth = 0;
    this.pixelMapHeight = 0;
    this.pixelMapInterlaced = null;

    this.w = 0;
    this.h = 0;

    this.lastMs = 0;
    this.serverMs = 0;
    this.lastErr = '';

    this.latestMs = 0;
    this.lastBroadcastMs = 0;

    this.lastAttemptMs = 0;
    this.lastSuccessMs = 0;

    this.lastLatestFetchMs = 0;
    this.lastImageFetchMs = 0;
    this.lastDecodeMs = 0;
    this.lastProcessMs = 0;
    this.lastAlarmGapMs = 0;

    this.consecutiveErrors = 0;

    this.running = false;
    this.timer = null;
    this.nextPollAt = 0;

    this.detector = new ShakeDetector();
    this.shakeJson = null;
    this.lastDetectMs = 0;
    this.lastDetectError = '';
  }

  start() {
    if (this.timer !== null || this.running) return;

    this.nextPollAt = performance.now();

    this.timer = setTimeout(() => {
      this.timer = null;
      this.poll();
    }, 0);
  }

  scheduleNext() {
    if (this.timer !== null) clearTimeout(this.timer);

    const now = performance.now();
    if (!this.nextPollAt) this.nextPollAt = now;

    this.nextPollAt += POLL_MS;

    // 処理が長引いた場合は遅れた周期を飛ばす
    while (this.nextPollAt <= now) this.nextPollAt += POLL_MS;

    this.timer = setTimeout(() => {
      this.timer = null;
      this.poll();
    }, Math.max(0, this.nextPollAt - now));
  }

  async poll() {
    if (this.running) return;

    this.running = true;

    const t0 = Date.now();

    if (this.lastAttemptMs) this.lastAlarmGapMs = t0 - this.lastAttemptMs;
    this.lastAttemptMs = t0;

    if (!this.nextPollAt) this.nextPollAt = performance.now();

    try {
      await this.step(clients.size);

      this.lastErr = '';
      this.consecutiveErrors = 0;

    } catch (e) {
      const msg = String((e && e.message) || e);

      this.lastErr = msg;
      this.consecutiveErrors++;

      this.broadcastText(JSON.stringify({
        type: 'error',
        msg,
        consecutiveErrors: this.consecutiveErrors
      }));

      console.error(new Date().toISOString(), 'collector:', msg);

    } finally {
      this.serverMs = Date.now() - t0;
      this.running = false;
      this.scheduleNext();
    }
  }

  async step(clientCount) {
    const t0 = Date.now();

    const latestStart = Date.now();
    const latest = await this.fetchLatest();
    this.lastLatestFetchMs = Date.now() - latestStart;
    this.latestMs = latest;

    // 新しい画像が公開されていなければ解析しない
    if (latest <= this.lastMs) {
      this.lastProcessMs = Date.now() - t0;
      return;
    }

    const points = await this.loadPoints();

    let img = null;
    let usedMs = 0;
    let lastError = null;

    const imageStart = Date.now();

    for (let i = 0; i <= FALLBACK_SECONDS; i++) {
      const cand = latest - i * 1000;

      if (cand <= this.lastMs) break;

      try {
        const res = await fetch(imageUrlFor(cand), {
          signal: AbortSignal.timeout(FETCH_TIMEOUT),
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        });

        if (!res.ok) throw new Error('画像 HTTP ' + res.status);

        const buf = new Uint8Array(await res.arrayBuffer());

        if (!buf.length) throw new Error('空の画像');

        const decodeStart = Date.now();
        img = decodeGif(buf);
        this.lastDecodeMs = Date.now() - decodeStart;

        usedMs = cand;
        break;

      } catch (e) {
        lastError = e;
      }
    }

    this.lastImageFetchMs = Date.now() - imageStart;

    if (!img) {
      throw new Error(
        '最新画像を取得できません。' + ((lastError && lastError.message) || '')
      );
    }

    let rebuilt = false;

    if (img.W !== this.w || img.H !== this.h || !this.stations.length) {
      this.w = img.W;
      this.h = img.H;

      this.stations = points.filter(
        p => p.x >= 0 && p.y >= 0 && p.x < img.W && p.y < img.H
      );

      this.detector.initialize(this.stations);

      const n = this.stations.length;

      this.prevKeys = new Uint32Array(n);
      this.stationLastSeenMs = new Float64Array(n);

      this.stationPixelIndices = new Int32Array(n);
      this.stationPixelIndices.fill(-1);

      // ブラウザーへ観測点の座標リストを送る（配列の並びを必ずServerと一致させる）
      this.stationsJson = JSON.stringify({
        type: 'stations',
        w: this.w,
        h: this.h,
        total: n,
        points: this.stations.map(s => [
          Math.round(s.lon * 1e5) / 1e5,
          Math.round(s.lat * 1e5) / 1e5
        ])
      });

      this.pixelMapLeft = -1;
      rebuilt = true;
    }

    // GIFの切り出し位置・サイズが変わったときだけ参照位置を再計算
    if (
      this.pixelMapLeft !== img.left ||
      this.pixelMapTop !== img.top ||
      this.pixelMapWidth !== img.w ||
      this.pixelMapHeight !== img.h ||
      this.pixelMapInterlaced !== img.interlaced ||
      this.stationPixelIndices.length !== this.stations.length
    ) {
      const n = this.stations.length;
      const pixelIndices = new Int32Array(n);
      pixelIndices.fill(-1);

      for (let i = 0; i < n; i++) {
        const station = this.stations[i];
        const col = station.x - img.left;
        const row = station.y - img.top;

        if (col >= 0 && row >= 0 && col < img.w && row < img.h) {
          pixelIndices[i] = img.rowPos[row] * img.w + col;
        }
      }

      this.stationPixelIndices = pixelIndices;
      this.pixelMapLeft = img.left;
      this.pixelMapTop = img.top;
      this.pixelMapWidth = img.w;
      this.pixelMapHeight = img.h;
      this.pixelMapInterlaced = img.interlaced;
    }

    const n = this.stations.length;
    const pal = img.pal;
    const changed = new Uint16Array(n);
    const intensities = new Array(n).fill(null);
    const receivedAtMs = Date.now();
    let changedCount = 0;

    for (let i = 0; i < n; i++) {
      const pixelIndex = this.stationPixelIndices[i];
      let freshKey = 0;
      let freshIntensity = null;

      // GIF透明色・範囲外・非震度色は「新しい観測値なし」
      if (pixelIndex >= 0) {
        const ci = img.px[pixelIndex];

        if (ci !== img.trans && pal && ci * 3 + 2 < pal.length) {
          const o = ci * 3;
          const r = pal[o];
          const g = pal[o + 1];
          const b = pal[o + 2];
          const pos = hsvPos(r, g, b);

          if (pos !== null) {
            freshKey = (((1 << 24) | (r << 16) | (g << 8) | b) >>> 0);
            freshIntensity = pos * 10 - 3;
          }
        }
      }

      const oldKey = this.prevKeys[i];

      if (freshKey) {
        this.prevKeys[i] = freshKey;
        this.stationLastSeenMs[i] = receivedAtMs;
        // 検知には「今回実際に受信できた値」だけを使う
        intensities[i] = freshIntensity;
      } else if (
        oldKey &&
        receivedAtMs - this.stationLastSeenMs[i] >= DISPLAY_HOLD_MS
      ) {
        this.prevKeys[i] = 0;
        this.stationLastSeenMs[i] = 0;
      }

      if (this.prevKeys[i] !== oldKey) changed[changedCount++] = i;
    }

    this.lastMs = usedMs;

    // 揺れ検知（失敗しても観測点表示は止めない）
    try {
      this.detector.update(intensities, usedMs);
      const snap = this.detector.snapshot();
      this.shakeJson = JSON.stringify({ type: 'shake_state', ...snap });
      this.lastDetectMs = usedMs;
      this.lastDetectError = '';
    } catch (e) {
      this.lastDetectError = String((e && e.stack) || e);
      console.error(new Date().toISOString(), '揺れ検知エラー:', e);
    }

    if (rebuilt) {
      this.broadcastText(this.stationsJson);
      this.broadcastBinary(
        this.buildFrame(this.fullIndices(), true, clientCount)
      );
    } else {
      this.broadcastBinary(
        this.buildFrame(changed, false, clientCount, changedCount)
      );
    }

    if (this.shakeJson) this.broadcastText(this.shakeJson);

    this.lastBroadcastMs = Date.now();
    this.lastSuccessMs = this.lastBroadcastMs;
    this.lastProcessMs = Date.now() - t0;
  }

  expireStaleStations(nowMs = Date.now()) {
    for (let i = 0; i < this.prevKeys.length; i++) {
      if (
        this.prevKeys[i] &&
        nowMs - this.stationLastSeenMs[i] >= DISPLAY_HOLD_MS
      ) {
        this.prevKeys[i] = 0;
        this.stationLastSeenMs[i] = 0;
      }
    }
  }

  fullIndices() {
    this.expireStaleStations(Date.now());
    const out = [];

    for (let i = 0; i < this.prevKeys.length; i++) {
      if (this.prevKeys[i] !== 0) out.push(i);
    }

    return out;
  }

  buildFrame(indices, full, clientCount, countOverride) {
    const count = countOverride ?? indices.length;

    const out = new Uint8Array(22 + count * 6);
    const dv = new DataView(out.buffer);

    dv.setUint8(0, 1);
    dv.setFloat64(1, this.lastMs, true);
    dv.setUint16(9, this.w, true);
    dv.setUint16(11, this.h, true);
    dv.setUint8(13, full ? 1 : 0);
    dv.setUint16(14, this.stations.length, true);
    dv.setUint16(16, count, true);
    dv.setUint16(18, Math.min(this.serverMs, 65535), true);
    dv.setUint16(20, clientCount ?? clients.size, true);

    let o = 22;

    for (let k = 0; k < count; k++) {
      const i = indices[k];
      const key = this.prevKeys[i];

      dv.setUint16(o, i, true);
      out[o + 2] = key ? 1 : 0;
      out[o + 3] = (key >> 16) & 255;
      out[o + 4] = (key >> 8) & 255;
      out[o + 5] = key & 255;

      o += 6;
    }

    return out;
  }

  sendSafe(ws, data, options) {
    if (ws.readyState !== WebSocket.OPEN) return;

    // 受信が追いつかないクライアントは切断して再同期させる
    if (ws.bufferedAmount > WS_MAX_BUFFER) {
      try { ws.terminate(); } catch {}
      return;
    }

    try {
      ws.send(data, options);
    } catch {}
  }

  broadcastBinary(data) {
    for (const ws of clients) {
      this.sendSafe(ws, data, { binary: true, compress: false });
    }
  }

  broadcastText(text) {
    for (const ws of clients) {
      this.sendSafe(ws, text, { binary: false, compress: false });
    }
  }

  /* 新規接続に現在の状態を一式送る（観測点リスト → 全件フレーム → 揺れ検知） */
  sendInitial(ws) {
    if (!this.stations.length || !this.lastMs) return;

    if (this.stationsJson) {
      this.sendSafe(ws, this.stationsJson, { binary: false, compress: false });
    }

    this.sendSafe(
      ws,
      this.buildFrame(this.fullIndices(), true, clients.size),
      { binary: true, compress: false }
    );

    if (this.shakeJson) {
      this.sendSafe(ws, this.shakeJson, { binary: false, compress: false });
    }
  }

  async fetchLatest() {
    const res = await fetch(LATEST_URL + '?_=' + Date.now(), {
      signal: AbortSignal.timeout(LATEST_TIMEOUT),
      cache: 'no-store',
      headers: {
        'Cache-Control': 'no-cache, no-store, max-age=0',
        'Pragma': 'no-cache'
      }
    });

    if (!res.ok) throw new Error('latest.json HTTP ' + res.status);

    const raw = await res.text();

    let data;

    try {
      data = JSON.parse(raw.replace(/^\uFEFF/, ''));
    } catch {
      throw new Error('latest.jsonのJSON解析に失敗しました');
    }

    return findLatestTime(data);
  }

  async loadPoints() {
    if (this.points) return this.points;
    if (this.pointsPromise) return this.pointsPromise;

    this.pointsPromise = (async () => {
      try {
        const res = await fetch(POINTS_URL, {
          signal: AbortSignal.timeout(8000),
          headers: { 'Cache-Control': 'no-cache' }
        });

        if (!res.ok) throw new Error('観測点JSON HTTP ' + res.status);

        const raw = await res.text();
        const data = JSON.parse(raw.replace(/^\uFEFF/, ''));
        const recs = walkRecords(data);

        if (!recs.length) throw new Error('観測点データが見つかりません');

        const prepared = preparePoints(recs);

        if (!prepared.length) throw new Error('有効な観測点がありません');

        this.points = prepared;
        return prepared;

      } catch (e) {
        this.pointsPromise = null;
        throw e;
      }
    })();

    return this.pointsPromise;
  }
}

const collector = new Collector();

/* ---------------- HTTP / WebSocket ---------------- */

const server = http.createServer((req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);

  // Serve the page from the same host as the WebSocket endpoint.
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
    fs.readFile(INDEX_FILE, (err, html) => {
      if (err) {
        res.writeHead(500, {
          'content-type': 'text/plain; charset=utf-8',
          'cache-control': 'no-store'
        });
        res.end('index.html を読み込めません: ' + err.message);
        return;
      }
      res.writeHead(200, {
        'content-type': 'text/html; charset=utf-8',
        'cache-control': 'no-store, no-cache, must-revalidate'
      });
      res.end(html);
    });
    return;
  }

  if (req.method === 'GET' && url.pathname === '/status') {
    const now = Date.now();
    const age = ms => (ms ? now - ms : null);
    const sec = v => (v !== null ? Number((v / 1000).toFixed(3)) : null);

    const det = collector.detector;
    const snap = det.snapshot();

    const body = {
      version: 'node collector v7-csharp-shake-port',

      clients: clients.size,
      stations: collector.stations.length,

      currentTime: now,
      currentTimeJST: formatJST(now),

      latestMs: collector.latestMs || null,
      latestJST: formatJST(collector.latestMs),

      lastImageMs: collector.lastMs || null,
      lastImageJST: formatJST(collector.lastMs),

      lastBroadcastMs: collector.lastBroadcastMs || null,
      lastBroadcastJST: formatJST(collector.lastBroadcastMs),

      latestAgeSeconds: sec(age(collector.latestMs)),
      imageAgeSeconds: sec(age(collector.lastMs)),

      pollIntervalMs: POLL_MS,
      displayHoldMs: DISPLAY_HOLD_MS,
      visibleStations: collector.prevKeys.reduce((c, k) => c + (k ? 1 : 0), 0),

      nextPollInMs:
        collector.timer !== null && collector.nextPollAt
          ? Math.max(0, Math.round(collector.nextPollAt - performance.now()))
          : null,

      serverMs: collector.serverMs,
      lastLatestFetchMs: collector.lastLatestFetchMs,
      lastImageFetchMs: collector.lastImageFetchMs,
      lastDecodeMs: collector.lastDecodeMs,
      lastProcessMs: collector.lastProcessMs,
      lastAlarmGapMs: collector.lastAlarmGapMs,

      lastAttemptMs: collector.lastAttemptMs || null,
      lastSuccessMs: collector.lastSuccessMs || null,

      consecutiveErrors: collector.consecutiveErrors,
      lastErr: collector.lastErr,

      alarmScheduled: collector.timer !== null,
      running: collector.running,

      detection: {
        lastDetectMs: collector.lastDetectMs || null,
        lastDetectJST: formatJST(collector.lastDetectMs),
        lastDetectError: collector.lastDetectError,
        confirmed: snap.confirmed,
        pending: snap.pending,
        events: snap.events.map(e => ({
          id: e.id,
          confirmed: !!e.c,
          level: e.l,
          points: e.pts.length
        })),
        pointsWithValidHistory: det.points.reduce((c, p) => c + (p.hasValidHistory ? 1 : 0), 0),
        pointsDisabled: det.points.reduce((c, p) => c + (p.tmpDisabled ? 1 : 0), 0)
      }
    };

    res.writeHead(200, {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'access-control-allow-origin': '*'
    });

    res.end(JSON.stringify(body, null, 2));
    return;
  }

  res.writeHead(426, {
    'content-type': 'text/plain; charset=utf-8',
    'cache-control': 'no-store'
  });

  res.end('WebSocket endpoint. GET /status for status.');
});

const wss = new WebSocketServer({
  noServer: true,
  perMessageDeflate: false,
  maxPayload: 1024 * 1024
});

server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);

  if (url.pathname !== '/') {
    socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
    socket.destroy();
    return;
  }

  if (
    ALLOWED_ORIGINS.length &&
    !ALLOWED_ORIGINS.includes(req.headers.origin || '')
  ) {
    socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
    socket.destroy();
    return;
  }

  wss.handleUpgrade(req, socket, head, ws => {
    wss.emit('connection', ws, req);
  });
});

wss.on('connection', ws => {
  if (ws._socket) ws._socket.setNoDelay(true);

  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });

  clients.add(ws);

  console.log(new Date().toISOString(), `WSS接続: ${clients.size} clients`);

  collector.sendInitial(ws);
  collector.start();

  ws.on('message', () => {
    ws.isAlive = true;
  });

  ws.on('close', () => {
    clients.delete(ws);
    console.log(new Date().toISOString(), `WSS切断: ${clients.size} clients`);
  });

  ws.on('error', err => {
    console.warn('WebSocket error:', err.message);
  });
});

// 無反応な接続を検出して切る
const pingTimer = setInterval(() => {
  for (const ws of clients) {
    if (!ws.isAlive) {
      try { ws.terminate(); } catch {}
      continue;
    }
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  }
}, WS_PING_MS);
pingTimer.unref();

server.listen(PORT, HOST, () => {
  console.log(`Node collector listening on http://${HOST}:${PORT}`);
  console.log(`Status: http://${HOST}:${PORT}/status`);
  console.log('常時稼働モード: 閲覧者が0人でも画像取得・揺れ検知を継続します。');
  collector.start();
});

function shutdown() {
  console.log('サーバーを終了します...');

  if (collector.timer !== null) clearTimeout(collector.timer);
  collector.timer = null;
  collector.nextPollAt = 0;

  for (const ws of clients) {
    try { ws.close(1001, 'server shutdown'); } catch {}
  }

  server.close(() => process.exit(0));

  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

process.on('unhandledRejection', e => {
  console.error('unhandledRejection:', e);
});

const p2 = n =>
  String(n).padStart(2, '0');

function imageUrlFor(ms) {
  const d = new Date(ms + 9 * 3600e3);

  const Y = d.getUTCFullYear();
  const M = p2(d.getUTCMonth() + 1);
  const D = p2(d.getUTCDate());

  const h = p2(d.getUTCHours());
  const m = p2(d.getUTCMinutes());
  const s = p2(d.getUTCSeconds());

  return (
    `${BASE_URL}${Y}${M}${D}/` +
    `${Y}${M}${D}${h}${m}${s}.jma_s.gif`
  );
}

function parseTimeValue(value) {
  if (typeof value === 'number') {
    if (value > 1000000000000) {
      return value;
    }

    if (value > 1000000000) {
      return value * 1000;
    }

    return null;
  }

  if (typeof value !== 'string') {
    return null;
  }

  const s = value.trim();

  if (/^\d{14}$/.test(s)) {
    const iso =
      `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}T` +
      `${s.slice(8, 10)}:${s.slice(10, 12)}:${s.slice(12, 14)}+09:00`;

    const ms = Date.parse(iso);

    return Number.isFinite(ms) ? ms : null;
  }

  const compact = s.match(
    /(\d{4})[/-](\d{2})[/-](\d{2})[ T](\d{2}):(\d{2}):(\d{2})/
  );

  if (compact) {
    const iso =
      `${compact[1]}-${compact[2]}-${compact[3]}T` +
      `${compact[4]}:${compact[5]}:${compact[6]}+09:00`;

    const ms = Date.parse(iso);

    return Number.isFinite(ms) ? ms : null;
  }

  if (/^\d{10,13}$/.test(s)) {
    const n = Number(s);

    if (n > 1000000000000) {
      return n;
    }

    if (n > 1000000000) {
      return n * 1000;
    }
  }

  return null;
}

function findLatestTime(data) {
  const candidates = [];

  function walk(value, key = '') {
    if (
      value === null ||
      value === undefined
    ) {
      return;
    }

    if (typeof value === 'object') {
      if (Array.isArray(value)) {
        for (const item of value) {
          walk(item, key);
        }

      } else {
        for (const [k, v] of Object.entries(value)) {
          walk(v, k);
        }
      }

      return;
    }

    const ms = parseTimeValue(value);

    if (ms === null) {
      return;
    }

    const name = String(key).toLowerCase();

    let priority = 0;

    if (name.includes('latest')) priority += 10;
    if (name.includes('time')) priority += 5;
    if (name.includes('date')) priority += 3;

    candidates.push({
      ms,
      priority
    });
  }

  walk(data);

  if (!candidates.length) {
    throw new Error(
      'latest.json内に認識可能な時刻がありません'
    );
  }

  candidates.sort((a, b) =>
    b.priority !== a.priority
      ? b.priority - a.priority
      : b.ms - a.ms
  );

  return candidates[0].ms;
}

function walkRecords(value, out = []) {
  if (Array.isArray(value)) {
    for (const v of value) {
      walkRecords(v, out);
    }

    return out;
  }

  if (value && typeof value === 'object') {
    if (
      value.location &&
      value.point &&
      value.point.center_point
    ) {
      out.push(value);
    }

    for (const v of Object.values(value)) {
      if (v && typeof v === 'object') {
        walkRecords(v, out);
      }
    }
  }

  return out;
}

function preparePoints(recs) {
  const result = [];

  for (const item of recs) {
    const loc = item.location || {};
    const point = item.point || {};

    const center = point.center_point || {};
    const offset = point.offset || {};

    const lat = Number(loc.latitude);
    const lon = Number(loc.longitude);

    const x =
      Number(center.x) +
      Number(offset.x || 0);

    const y =
      Number(center.y) +
      Number(offset.y || 0);

    if (
      !Number.isFinite(lat) ||
      !Number.isFinite(lon) ||
      !Number.isFinite(x) ||
      !Number.isFinite(y)
    ) {
      continue;
    }

    if (item.is_suspended === true) {
      continue;
    }

    result.push({
      x: Math.round(x),
      y: Math.round(y),
      lat, lon,
      name: item.name || item.point_name || item.station_name || item.code || '観測点',
      region: item.region || item.prefecture || '',
      code: item.code || ''
    });
  }

  return result;
}

function decodeGif(buf) {
  const u16 = p =>
    buf[p] | (buf[p + 1] << 8);

  if (
    buf[0] !== 0x47 ||
    buf[1] !== 0x49 ||
    buf[2] !== 0x46
  ) {
    throw new Error('GIFではありません');
  }

  const W = u16(6);
  const H = u16(8);

  const gf = buf[10];

  let p = 13;
  let gct = null;

  if (gf & 0x80) {
    const n = 3 * (2 << (gf & 7));

    gct = buf.subarray(p, p + n);

    p += n;
  }

  let trans = -1;

  while (p < buf.length) {
    const b = buf[p++];

    if (b === 0x21) {
      const label = buf[p++];

      if (label === 0xf9 && buf[p] >= 4) {
        if (buf[p + 1] & 1) {
          trans = buf[p + 4];
        }
      }

      let sz;

      while (
        p < buf.length &&
        (sz = buf[p++]) !== 0
      ) {
        p += sz;
      }

    } else if (b === 0x2c) {
      const left = u16(p);
      const top = u16(p + 2);

      const w = u16(p + 4);
      const h = u16(p + 6);

      const f = buf[p + 8];

      p += 9;

      let pal = gct;

      if (f & 0x80) {
        const n = 3 * (2 << (f & 7));

        pal = buf.subarray(p, p + n);

        p += n;
      }

      const minCode = buf[p++];

      let total = 0;
      let q = p;
      let sz;

      while (
        q < buf.length &&
        (sz = buf[q++]) !== 0
      ) {
        total += sz;
        q += sz;
      }

      const data = new Uint8Array(total);

      let dp = 0;
      q = p;

      while (
        q < buf.length &&
        (sz = buf[q++]) !== 0
      ) {
        data.set(
          buf.subarray(q, q + sz),
          dp
        );

        dp += sz;
        q += sz;
      }

      const px = new Uint8Array(w * h);

      lzwDecode(minCode, data, px);

      const rowPos = new Uint16Array(h);

      if (f & 0x40) {
        let d = 0;

        for (const [start, step] of [
          [0, 8],
          [4, 8],
          [2, 4],
          [1, 2]
        ]) {
          for (
            let r = start;
            r < h;
            r += step
          ) {
            rowPos[r] = d++;
          }
        }

      } else {
        for (let r = 0; r < h; r++) {
          rowPos[r] = r;
        }
      }

      return {
        W,
        H,
        left,
        top,
        w,
        h,
        pal,
        trans,
        px,
        rowPos,
        interlaced: !!(f & 0x40)
      };

    } else if (b === 0x3b) {
      break;

    } else {
      throw new Error('不明なGIFブロック');
    }
  }

  throw new Error('GIF画像データがありません');
}

function lzwDecode(minCode, data, out) {
  const clear = 1 << minCode;
  const eoi = clear + 1;

  let size = minCode + 1;
  let mask = (1 << size) - 1;

  let next = eoi + 1;

  const prefix = new Uint16Array(4096);
  const suffix = new Uint8Array(4096);
  const stack = new Uint8Array(4097);

  for (let c = 0; c < clear; c++) {
    suffix[c] = c;
  }

  const n = out.length;

  let bits = 0;
  let datum = 0;

  let ip = 0;
  let op = 0;

  let old = -1;
  let first = 0;

  while (op < n) {
    while (bits < size) {
      if (ip >= data.length) {
        return op;
      }

      datum |= data[ip++] << bits;
      bits += 8;
    }

    let code = datum & mask;

    datum >>= size;
    bits -= size;

    if (code === clear) {
      size = minCode + 1;
      mask = (1 << size) - 1;

      next = eoi + 1;
      old = -1;

      continue;
    }

    if (code === eoi) {
      break;
    }

    if (old === -1) {
      out[op++] = suffix[code];

      old = code;
      first = code;

      continue;
    }

    const inCode = code;

    let sp = 0;

    if (code >= next) {
      stack[sp++] = first;
      code = old;
    }

    while (code >= clear) {
      stack[sp++] = suffix[code];
      code = prefix[code];
    }

    first = suffix[code];

    stack[sp++] = first;

    if (next < 4096) {
      prefix[next] = old;
      suffix[next] = first;

      next++;

      if (
        (next & mask) === 0 &&
        next < 4096
      ) {
        size++;
        mask = (1 << size) - 1;
      }
    }

    old = inCode;

    while (sp > 0 && op < n) {
      out[op++] = stack[--sp];
    }
  }

  return op;
}
